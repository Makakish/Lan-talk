# LAN TALK — Android LAN chat (starter MVP)

This is the first Android Studio source project for the LAN TALK prototype.

## Current prototype
- One Android phone can host a TCP room on port `45454`.
- Other phones join by entering the host phone's local IPv4 address.
- Text messages are broadcast to connected clients.
- Incoming messages can be read aloud using Android Text-to-Speech.
- The app tries to choose a stable Russian TTS voice per sender on each receiving phone and also varies pitch as a fallback.

## Build
1. Install Android Studio (recent version) with Android SDK 35.
2. Open this folder (`LanTalk`) as a project.
3. Let Gradle sync.
4. Build > Build APK(s).
5. Install the debug APK on Android phones on the same Wi-Fi network.

## First test
1. Connect all phones to the same Wi-Fi network (or connect them to the host phone's hotspot).
2. On one phone, enter a name and tap **Создать комнату**. Note the displayed IP address.
3. On each other phone, enter a name, type the host IP and tap **Подключиться**.
4. Send a message.

## Important prototype limitations
- This is an early source prototype, not a production-ready messenger and no APK has been compiled in this environment.
- Current room discovery is manual IP entry; automatic discovery, QR join, participant list, room password, private messages, persistent history and voice-call/PTT are not implemented yet.
- The current server is a simple TCP prototype. It needs hardened connection handling, explicit client registration, duplicate-message prevention, reconnect handling, message size limits and testing with 50 devices before claiming 50-user reliability.
- Voice choice is local to each receiving Android device. Different devices may have different installed TTS voices; install Russian voice data in Android's Text-to-Speech settings for best results.
- Keep the host app open while hosting. Android battery/background restrictions may stop a prototype server if the app is backgrounded.
- Use only on a trusted local network: this prototype does not encrypt chat traffic or authenticate users.
