package com.example.lantalk

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.ServerSocket
import java.net.Socket
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val port = 45454
    private var server: ServerSocket? = null
    private var client: Socket? = null
    private var clientWriter: PrintWriter? = null
    private val peers = CopyOnWriteArrayList<PrintWriter>()
    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var nameInput: EditText
    private lateinit var ipInput: EditText
    private lateinit var messageInput: EditText
    private lateinit var speakSwitch: Switch
    private var ttsReady = false
    private val voiceBySender = mutableMapOf<String, Voice>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 18)
            setBackgroundColor(0xFF101820.toInt())
        }
        fun label(text: String, size: Float = 16f): TextView = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(0xFFF1F5F9.toInt())
        }
        val title = label("LAN TALK", 27f).apply { typeface = Typeface.DEFAULT_BOLD }
        root.addView(title)
        root.addView(label("Локальный групповой чат · до 50 участников", 13f))
        status = label("Не подключено", 14f)
        status.setPadding(0, 16, 0, 12)
        root.addView(status)
        nameInput = EditText(this).apply { hint = "Ваше имя"; setSingleLine(); setTextColor(-1); setHintTextColor(0xFF94A3B8.toInt()) }
        root.addView(nameInput, matchWrap())
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val hostButton = Button(this).apply { text = "Создать комнату"; setOnClickListener { startHost() } }
        row.addView(hostButton, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row)
        ipInput = EditText(this).apply { hint = "IP организатора, например 192.168.1.5"; setSingleLine(); setTextColor(-1); setHintTextColor(0xFF94A3B8.toInt()) }
        root.addView(ipInput, matchWrap())
        val joinButton = Button(this).apply { text = "Подключиться"; setOnClickListener { joinRoom() } }
        root.addView(joinButton)
        speakSwitch = Switch(this).apply { text = "Озвучивать входящие сообщения"; isChecked = true; setTextColor(-1) }
        root.addView(speakSwitch)
        val chatTitle = label("Сообщения", 18f).apply { typeface = Typeface.DEFAULT_BOLD; setPadding(0, 14, 0, 6) }
        root.addView(chatTitle)
        log = label("Здесь появится переписка", 14f)
        val scroll = ScrollView(this).apply { addView(log) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        messageInput = EditText(this).apply { hint = "Написать сообщение…"; setTextColor(-1); setHintTextColor(0xFF94A3B8.toInt()) }
        val sendRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        sendRow.addView(messageInput, LinearLayout.LayoutParams(0, -2, 1f))
        sendRow.addView(Button(this).apply { text = "Отправить"; setOnClickListener { sendMessage() } })
        root.addView(sendRow)
        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8; bottomMargin = 5 }

    private fun myName() = nameInput.text.toString().trim().ifBlank { "Участник" }

    private fun startHost() {
        if (server != null) return
        thread {
            try {
                server = ServerSocket(port)
                val address = localIpAddress() ?: "IP не определён"
                runOnUiThread { status.text = "Комната запущена · $address:$port" }
                while (true) {
                    val socket = server!!.accept()
                    val writer = PrintWriter(socket.getOutputStream(), true)
                    peers.add(writer)
                    thread { readSocket(socket, true) }
                    broadcast(JSONObject().put("type", "system").put("text", "Новый участник подключился").toString())
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Ошибка сервера: ${e.message}" }
            }
        }
    }

    private fun joinRoom() {
        val host = ipInput.text.toString().trim()
        if (host.isBlank()) { toast("Укажи IP телефона-организатора"); return }
        thread {
            try {
                val socket = Socket(host, port)
                client = socket
                clientWriter = PrintWriter(socket.getOutputStream(), true)
                runOnUiThread { status.text = "Подключено к $host" }
                readSocket(socket, false)
            } catch (e: Exception) {
                runOnUiThread { status.text = "Не удалось подключиться: ${e.message}" }
            }
        }
    }

    private fun readSocket(socket: Socket, isHostPeer: Boolean) {
        try {
            val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
            while (true) {
                val line = reader.readLine() ?: break
                if (isHostPeer) broadcast(line) else handleIncoming(line)
            }
        } catch (_: Exception) { }
        finally { try { socket.close() } catch (_: Exception) {} }
    }

    private fun sendMessage() {
        val text = messageInput.text.toString().trim()
        if (text.isBlank()) return
        val packet = JSONObject().put("type", "message").put("sender", myName()).put("text", text).toString()
        if (server != null) {
            broadcast(packet)
        } else if (clientWriter != null) {
            // The host echoes the message to every client, including its sender.
            clientWriter?.println(packet)
        } else { toast("Сначала создай комнату или подключись") ; return }
        messageInput.setText("")
    }

    private fun broadcast(line: String) {
        peers.forEach { writer -> try { writer.println(line) } catch (_: Exception) { peers.remove(writer) } }
        // Host also displays messages received from connected clients.
        try { handleIncoming(line) } catch (_: Exception) {}
    }

    private fun handleIncoming(line: String) {
        try {
            val obj = JSONObject(line)
            when (obj.optString("type")) {
                "message" -> {
                    val sender = obj.optString("sender", "Участник")
                    val text = obj.optString("text", "")
                    runOnUiThread { appendMessage(sender, text, true) }
                }
                "system" -> runOnUiThread { log.append("\n• ${obj.optString("text")}") }
            }
        } catch (_: Exception) { }
    }

    private fun appendMessage(sender: String, text: String, speak: Boolean) {
        runOnUiThread {
            log.append("\n$sender: $text\n")
            if (speak && speakSwitch.isChecked) speakFor(sender, text)
        }
    }

    // Assign a stable voice profile per sender on this device. Voice availability varies by Android TTS engine.
    private fun speakFor(sender: String, text: String) {
        if (!ttsReady) return
        val voices = tts.voices?.filter { it.locale.language == "ru" && !it.isNetworkConnectionRequired } ?: emptyList()
        if (voices.isNotEmpty()) {
            val voice = voiceBySender.getOrPut(sender) {
                val index = (sender.lowercase().hashCode().and(Int.MAX_VALUE)) % voices.size
                voices[index]
            }
            try { tts.voice = voice } catch (_: Exception) { }
        }
        val pitch = when ((sender.lowercase().hashCode().and(Int.MAX_VALUE)) % 4) {
            0 -> 0.82f; 1 -> 0.95f; 2 -> 1.08f; else -> 1.2f
        }
        tts.setPitch(pitch)
        tts.setSpeechRate(0.96f)
        tts.speak("$sender говорит. $text", TextToSpeech.QUEUE_ADD, null, "msg_${System.nanoTime()}")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale("ru")
            ttsReady = true
        }
    }

    private fun localIpAddress(): String? {
        try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            for (intf in interfaces) for (addr in Collections.list(intf.inetAddresses)) {
                if (!addr.isLoopbackAddress && addr is Inet4Address) return addr.hostAddress
            }
        } catch (_: Exception) { }
        return null
    }

    private fun toast(message: String) = runOnUiThread { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }

    override fun onDestroy() {
        try { server?.close() } catch (_: Exception) {}
        try { client?.close() } catch (_: Exception) {}
        try { tts.stop(); tts.shutdown() } catch (_: Exception) {}
        super.onDestroy()
    }
}
